import React, { Fragment, useState } from 'react';
import { Link } from 'react-router-dom'
import useForm from './useForm';
import validateInfo from './signUpValidator';
import axios from 'axios';

const api = axios.create({
    baseURL: 'http://localhost:5000/',
});

const SignUp = () => {
    const [isSubmitted, setIsSubmitted] = useState(false);

    const submitForm = (data) => {
        const postData = {
            username: data.username,
            password: data.password,
            phoneNumber: Number(data.phoneNumber),
            emailId: data.email,
            userType: data.accType
        }

        api.post('/users/', postData).then((res) => {
            //console.log(res.status, res.statusText)
            if (res.status === 201) {
                setIsSubmitted(true);
            }
        }).catch(err => console.log(err));
    }

    const { handleChange, handleSubmit, values, errors } = useForm(submitForm, validateInfo);

    return (
        <Fragment>
            {isSubmitted ? <SuccessForm /> :
                <div className='container mt-5' style={formStyles}>
                    <form onSubmit={handleSubmit}>
                        <h4>Register</h4>
                        <div className='row mb-3'>
                            <label htmlFor="inputusername" className="col-form-label col-sm-4 d-flex justify-content-end"><strong>Username</strong></label>
                            <div className="form-group col-sm-8">
                                <input type="text"
                                    className="form-control"
                                    id="inputusername"
                                    name='username'
                                    placeholder='kavya'
                                    value={values.username}
                                    onChange={handleChange}
                                />
                            </div>
                        </div>
                        {errors.username && <p style={errorStyles}>&#9888; {errors.username}</p>}
                        <div className='row mb-3'>
                            <label htmlFor="inputemail" className="col-sm-4 col-form-label d-flex justify-content-end"><strong>Email Address</strong></label>
                            <div className="form-group col-sm-8">
                                <input type="email"
                                    className="form-control"
                                    id="inputemail"
                                    name='email'
                                    placeholder='kavya@abc.com'
                                    value={values.email}
                                    onChange={handleChange}
                                />
                            </div>
                        </div>
                        {/* {errors.email && <p style={errorStyles}>{errors.email}</p>} */}
                        <div className='row mb-3'>
                            <label htmlFor="inputNumber" className="col-sm-4 col-form-label d-flex justify-content-end"><strong>Phone Number</strong></label>
                            <div className="form-group col-sm-8">
                                <input type="number"
                                    className="form-control"
                                    id="inputNumber"
                                    name='phoneNumber'
                                    placeholder='9691836008'
                                    value={values.phoneNumber}
                                    onChange={handleChange}
                                />
                            </div>
                        </div>
                        {errors.phoneNumber && <p style={errorStyles}>&#9888; {errors.phoneNumber}</p>}
                        <div className='row mb-3'>
                            <label htmlFor="inputPassword" className="col-sm-4 col-form-label d-flex justify-content-end"><strong>Password</strong></label>
                            <div className="form-group col-sm-8">
                                <input type="password"
                                    className="form-control"
                                    id="inputPassword"
                                    name='password'
                                    placeholder='*******'
                                    value={values.password}
                                    onChange={handleChange}
                                />
                            </div>
                        </div>
                        {errors.password && <p style={errorStyles}>&#9888; {errors.password}</p>}
                        <div className='row mb-3'>
                            <label htmlFor="inputConfirmPwd" className="col-sm-4 col-form-label d-flex justify-content-end"><strong>Confirm Password</strong></label>
                            <div className="form-group col-sm-8">
                                <input type="password"
                                    className="form-control"
                                    id="inputConfirmPwd"
                                    name='confirmPassword'
                                    placeholder='*******'
                                    value={values.confirmPassword}
                                    onChange={handleChange}
                                />
                            </div>
                        </div>
                        <div className='row mb-3' >
                            <label className="col-sm-4 col-form-label d-flex justify-content-end"><strong>Account Type</strong></label>
                            <div className="form-group form-check form-check-inline col-sm-2" style={{ marginLeft: '1em' }}>
                                <input type="radio"
                                    className="form-check-input"
                                    id="inputBuyer"
                                    name='accType'
                                    value='buyer'
                                    onChange={handleChange}
                                />
                                <label htmlFor="inputBuyer" className="form-check-label"><b>Buyer</b></label>
                            </div>
                            <div className="form-group form-check form-check-inline col-sm-2">
                                <input type="radio"
                                    className="form-check-input"
                                    id="inputSeller"
                                    name='accType'
                                    value='seller'
                                    onChange={handleChange}
                                />
                                <label htmlFor="inputSeller" className="form-check-label"><b>Seller</b></label>
                            </div>
                        </div>

                        {errors.confirmPassword && <p style={errorStyles}>&#9888; {errors.confirmPassword}</p>}
                        {errors.mandatory && <p style={errorStyles}>&#9888; {errors.mandatory}</p>}
                        <button type="submit" className="btn btn-primary mt-2" >Register</button>
                    </form >
                </div >
            }
        </Fragment>
    )
}

const SuccessForm = () => {
    return (
        <div className='container mt-5' style={{ maxWidth: '400px' }}>
            <div className="row">
                <div className="card bg-success" style={{ color: 'white', padding: '10px' }}>
                    <h2>User has been registered successfully!</h2>
                    <div className="card-body">
                        <Link to="/login" className="btn btn-primary mt-2" >Go to Login</Link>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default SignUp;

const formStyles = {
    maxWidth: '550px',
    backgroundColor: 'lightblue',
    padding: '20px',
    borderRadius: '10px'
}

const errorStyles = {
    fontSize: "0.7rem",
    fontWeight: 'bold',
    marginTop: "0.5rem",
    color: '#f00e0e',
}